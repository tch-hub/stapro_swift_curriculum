//
//  TimerApp.swift
//  Timer
//
//  Created by mogi yoshiki on 2024/04/09.
//

import SwiftUI

@main
struct TimerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
