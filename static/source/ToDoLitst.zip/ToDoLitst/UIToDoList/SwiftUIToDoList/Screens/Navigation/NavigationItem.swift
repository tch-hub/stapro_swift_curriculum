/// 画面遷移の情報
struct NavigationItem: Hashable {
    let id: ScreenID // 画面ID
}
