# SwiftUI ToDoリストアプリ

![コース画像](./images/コース画像.png)

## 概要

Udemyで公開している [【2025年 最新版】SwiftUI & Swift6対応 これ1本でOK！アプリ開発に必要なスキルが身につく決定版講座](https://www.udemy.com/course/draft/6475537/?referralCode=28C3A798E91A72A2B881) の題材として使用する **ToDoリストアプリ** のリポジトリです。

[Wiki](https://github.com/sakes9/SwiftUIToDoList/wiki) には開発環境の構築方法やプロジェクトの作成方法、使用しているライブラリのインストール方法などを記載しています。
